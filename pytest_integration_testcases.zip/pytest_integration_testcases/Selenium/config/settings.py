import os

# 登录相关配置
USERNAME = "your_account"  # 替换为你的百度账号
PASSWORD = "your_password"  # 替换为你的密码

# 截图保存目录
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCREENSHOT_DIR = os.path.join(BASE_DIR, "screenshots")

# 浏览器配置
BROWSER = "chrome"  # 可以设置为 "chrome", "firefox", 或 "edge"
IMPLICIT_WAIT = 10  # 隐式等待时间（秒）
