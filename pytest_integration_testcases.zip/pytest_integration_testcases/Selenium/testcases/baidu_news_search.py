from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import time
from util.logger import setup_logger
from util.browser import get_browser
from config.settings import SCREENSHOT_DIR

# 初始化日志记录器
logger = setup_logger(log_file="test_search.log")

# 确保截图目录存在
if not os.path.exists(SCREENSHOT_DIR):
    os.mkdir(SCREENSHOT_DIR)


def baidu_news_search():
    """在百度搜索关键词并检查搜索结果"""
    logger.info("===== 开始测试：百度搜索关键词 =====")

    # 初始化测试结果变量
    test_result = "失败"

    # 初始化浏览器
    logger.info("启动浏览器...")
    driver = get_browser()
    try:
        # 1. 打开百度首页
        driver.get("https://www.baidu.com")
        logger.info("已打开百度首页")
        driver.save_screenshot(os.path.join(SCREENSHOT_DIR, "opened_baidu_homepage.png"))
        logger.info("已保存打开百度首页截图")

        # 2. 使用显式等待等待搜索框加载完成
        search_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "kw"))
        )
        logger.info("搜索框已加载")

        # 3. 输入关键词
        keyword = "人工智能"
        search_box.send_keys(keyword)
        # search_box.send_keys("元宇宙")
        logger.info(f"已输入关键词: {keyword}")

        # 4. 提交搜索
        search_box.submit()
        logger.info("已提交搜索请求")

        # 5. 等待搜索结果页面加载
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, '#content_left .result.c-container'))
        )
        logger.info("搜索结果页面已加载")

        # 6. 检查页面标题是否包含关键词
        if keyword in driver.title:
            logger.info(f"页面标题包含关键词 '{keyword}'，搜索成功")
            test_result = "成功"
        else:
            logger.error(f"页面标题不包含关键词 '{keyword}'，搜索失败")
            raise Exception(f"测试失败：页面标题未包含关键词 '{keyword}'")

        # 保存成功截图
        driver.save_screenshot(os.path.join(SCREENSHOT_DIR, "search_results.png"))
        logger.info("已保存搜索结果页面截图")
        test_result = "成功"

    except Exception as e:
        logger.error(f"测试过程中发生错误: {str(e)}")
        driver.save_screenshot(os.path.join(SCREENSHOT_DIR, "search_error.png"))
        logger.info("已保存错误截图")

    finally:
        time.sleep(5)
        driver.quit()
        logger.info("关闭浏览器")
        logger.info(f"===== 测试结束，结果: {test_result} =====")
        return test_result


if __name__ == "__main__":
    result = baidu_news_search()
    logger.info(f"测试最终结果: {result}")
