import pytest
import shutil
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
from util.logger import setup_logger
from util.browser import get_browser
from config.settings import SCREENSHOT_DIR

@pytest.fixture(scope="session")
def logger():
    """初始化日志记录器"""
    return setup_logger(log_file="test_search.log")

@pytest.fixture(scope="session", autouse=True)
def ensure_screenshot_dir():
    """确保截图目录存在"""
    if os.path.exists(SCREENSHOT_DIR):
        shutil.rmtree(SCREENSHOT_DIR)  # 删除整个目录及其内容
    os.mkdir(SCREENSHOT_DIR)  # 重新创建空目录

@pytest.fixture(scope="module")
def driver(logger):
    """创建浏览器实例并在测试模块中共享"""
    logger.info("启动浏览器...")
    browser = get_browser()
    yield browser
    logger.info("关闭浏览器...")
    browser.quit()

# 参数化关键词
KEYWORDS = ["人工智能", "量子计算", "自动驾驶", "区块链", "深度学习"]

@pytest.mark.parametrize("keyword", KEYWORDS)
def test_baidu_news_search(driver, logger, keyword):
    # 打开百度首页
    driver.get("https://www.baidu.com")
    logger.info("已打开百度首页")
    driver.save_screenshot(os.path.join(SCREENSHOT_DIR, f"opened_baidu_homepage_{keyword}.png"))
    assert "百度" in driver.title, "百度首页未正确加载"

    # 搜索框输入关键词
    search_box = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "kw"))
    )
    logger.info("搜索框已加载")
    search_box.clear()  # 清空输入框
    search_box.send_keys(keyword)
    logger.info(f"已输入关键词: {keyword}")

    # 提交搜索
    search_box.submit()
    logger.info("已提交搜索请求")

    # 验证搜索结果页面加载完成
    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, '#content_left .result.c-container'))
    )
    logger.info(f"搜索结果页面已加载: {keyword}")
    driver.save_screenshot(os.path.join(SCREENSHOT_DIR, f"search_submitted_{keyword}.png"))

    # 验证页面标题包含关键词
    assert keyword in driver.title, f"页面标题未包含关键词: {keyword}"

    # 验证至少有一个搜索结果
    search_results = driver.find_elements(By.CSS_SELECTOR, '#content_left .result.c-container')
    assert len(search_results) > 0, f"搜索结果为空: {keyword}"
    logger.info(f"搜索结果数量: {len(search_results)} ({keyword})")
    driver.save_screenshot(os.path.join(SCREENSHOT_DIR, f"search_results_{keyword}.png"))

if __name__ == "__main__":
    pytest.main(["-v", os.path.basename(__file__)])
