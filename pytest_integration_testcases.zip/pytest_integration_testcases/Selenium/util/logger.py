import logging
import os

def setup_logger(log_dir=None, log_file="test.log"):
    """
    设置日志记录器
    :param log_dir: 日志目录，默认为与 testcases 同级的 logs 文件夹
    :param log_file: 日志文件名
    :return: logger 对象
    """
    # 获取当前脚本所在目录的绝对路径
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # 如果 log_dir 未指定，默认设置为与 testcases 同级的 logs 文件夹
    if not log_dir:
        log_dir = os.path.join(base_dir, "logs")

    # 确保日志目录存在
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 创建日志记录器
    logger = logging.getLogger("TestLogger")
    logger.setLevel(logging.INFO)

    # 日志格式
    formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )

    # 文件日志处理器
    file_handler = logging.FileHandler(os.path.join(log_dir, log_file), encoding="utf-8")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    # 控制台日志处理器
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return logger
