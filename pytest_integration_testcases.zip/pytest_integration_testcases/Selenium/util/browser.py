from selenium import webdriver
from config.settings import BROWSER, IMPLICIT_WAIT


def get_browser():
    """
    根据配置文件中的浏览器类型初始化浏览器
    :return: 浏览器实例
    """
    browser_type = BROWSER.lower()  # 从配置文件中读取浏览器类型

    if browser_type == "chrome":
        driver = webdriver.Chrome()
    elif browser_type == "firefox":
        driver = webdriver.Firefox()
    elif browser_type == "edge":
        driver = webdriver.Edge()
    else:
        raise ValueError(f"不支持的浏览器类型: {browser_type}")

    driver.maximize_window()
    driver.implicitly_wait(IMPLICIT_WAIT)  # 设置隐式等待时间
    return driver
